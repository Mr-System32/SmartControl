#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

int main()
{
	int N_Book, N_Librrary, N_Days;
	ofstream file;
	file.open("codebind.txt");
	ifstream myfile("C:\\Users\\Ashref\\Desktop\\f_libraries_of_the_world.txt");          //opening the file.
	vector<string> vect;
	vector<int> vect1;
	vector<vector<int>> vect2;
	vector<vector<int>> librrary;
	vector<vector<int>> books;
	string s;

	if (myfile.is_open())                     //if the file is open
	{
		
		getline(myfile, s);
		myfile >> N_Book>> N_Librrary>> N_Days;
		getline(myfile, s);
		
		while (myfile.good())
		{
			getline(myfile, s);
			vect.push_back(s);
		}

		for (int i = 0; i < vect.size(); i++) {
			string h = vect[i];
			int a = h.length();
			int c[10000] = { 0 };
			int  j = 0;
			for (int i = 0; h[i] != '\0'; i++) {
				if (h[i] == ' ') {
					j++;
				}
				else {
					c[j] = c[j] * 10 + (h[i] - 48);
			}				
				
			}
			for (int i = 0; i <= j; i++) {
				vect1.push_back(c[i]);
				
			}

			vect2.push_back(vect1);
			vect1.clear();
			j = 0;
		}
		int l = 0;
		file <<"1000"<< endl;
		for (int i = 0; i < vect2.size() ; i++) {
			if (i % 2 == 0)
			{
				file << l++ << " " << vect2[i][0] << endl;
			
			
		}else if (i % 2 == 1) {
			for (int j = 0; j < vect2[i].size(); j++) {
				//books.push_back(vect2[i][j]);
				file << vect2[i][j] << " ";
			}
			file << endl;
		}		
		}
		
		//cout << l;
		for (int i = 0; i < 10000; i++)
		{
		//	file << i << " " << librrary[0][i]<<endl;
		}

	}
	else cout << "Unable to open file";
	myfile.close();
	file.close();

	return 0;

}

